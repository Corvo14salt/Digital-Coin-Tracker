
    const pricesContainer = document.getElementById('prices');
    const lastUpdated = document.getElementById('last-updated');
    const prevPageButton = document.getElementById('prev-page');
    const nextPageButton = document.getElementById('next-page');
    const currentPageSpan = document.getElementById('current-page');

    let currentPage = 1;

    // Fetch data from API
    async function fetchPrices(page = 1) {
      try {
        const response = await fetch(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=${page}`);
        const data = await response.json();
        displayPrices(data);
        lastUpdated.textContent = `آخر تحديث: ${new Date().toLocaleTimeString()}`;
      } catch (error) {
        console.error('Error fetching data:', error);
        pricesContainer.innerHTML = '<p>حدث خطأ أثناء تحميل البيانات.</p>';
      }
    }

    // Display prices
    function displayPrices(data) {
      pricesContainer.innerHTML = '';
      data.forEach(coin => {
        const coinElement = document.createElement('div');
        coinElement.className = 'coin';
        coinElement.innerHTML = `
          <img src="${coin.image}" alt="${coin.name}" />
          <span>${coin.name} (${coin.symbol.toUpperCase()}): $${coin.current_price.toLocaleString()}</span>
        `;
        pricesContainer.appendChild(coinElement);
      });
    }

    // Pagination
    prevPageButton.addEventListener('click', () => {
      if (currentPage > 1) {
        currentPage--;
        fetchPrices(currentPage);
        updatePagination();
      }
    });

    nextPageButton.addEventListener('click', () => {
      currentPage++;
      fetchPrices(currentPage);
      updatePagination();
    });

    function updatePagination() {
      currentPageSpan.textContent = `الصفحة: ${currentPage}`;
      prevPageButton.disabled = currentPage === 1;
    }

    // Initial fetch
    fetchPrices();
    